import React from 'react';

const Avatarlist = (props) => {
    return (
           <div className="avaterstyle ma4 bg-light-gray dib pa4 tc grow shadow-4">
        <img src={`https://joeschmoe.io/api/v1/${props.name}`} alt="Aavatar" />
        
       
    <h1> {props.name}</h1>
    <p> {props.work} </p>
    <button className="ma4 bg-light-yellow  pa2  grow ">Click For Details</button>

    </div>
    
    )
}
export default Avatarlist ;
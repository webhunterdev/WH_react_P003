import React from 'react';
import './Avatar.css';
import Avatarlist from './Avatarlist';
import 'tachyons';
 const Avatar = (props) => {
     const avatarlistarray = [
         {
         id:1,
         name:"Steve Jobs",
         work:"Web developer"
     },
     {
        id:1,
        name:"Bill Gets",
        work:"Programmer"
    },
    {
        id:1,
        name:"Harved John",
        work:"C ++ programmer"
    },
    {
        id:1,
        name:"Rafi Ahmed",
        work:"QA Engineer"
    }
   
   
   
    
    ]
     return (
        
     <div class="tc " >
         <h1>Wellcome to Lagends World</h1>
         <Avatarlist id="1" name={avatarlistarray[0].name} work={avatarlistarray[0].work}/>
         <Avatarlist id="1" name={avatarlistarray[1].name} work={avatarlistarray[1].work}/>
         <Avatarlist id="1" name={avatarlistarray[2].name} work={avatarlistarray[2].work}/>
         <Avatarlist id="1" name={avatarlistarray[3].name} work={avatarlistarray[3].work}/>
         <br></br>
         

     </div>
     
     )
 }
 export default Avatar ;